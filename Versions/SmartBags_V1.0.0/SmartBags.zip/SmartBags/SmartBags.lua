-- Name: SmartBags
-- Version: 1.0
-- Author: Reikan
-- Description: Show free slots, inventory slots, money and money in bank / Affiche la place disponible dans l'inventaire, l'argent en poche et l'argent en banque
-- To Do : Gold Money Icon, Bank Slots available

SmartBags = {}
SmartBags.name = "SmartBags"
SmartBags.version = "v1.0.0"
SmartBags.settingsVersion = 1;
SmartBags.settingsDefaults = {
	ShowInfo = 0;
	LocalLang = "EN";
	wndMain = {
		x = 10;
		y = 10;
		width = 500;
		height = 40;
	}
}

local ShowInfo = 0
local ShowAddonNameInfo = string.format("|cffffcc[%s] : |r", SmartBags.name)
-- Localisation variables
local Lang = "EN"
local FreeSlots = ""
local BagTotalSpace = ""
local Money = ""
local Bank = ""
local AddonIsMoving = ""
local DisplayOn = ""

-- Initialisation
function SmartBags.Initialize( eventCode, addOnName )
	-- Initialisation only for SmartBags
	if ( addOnName ~= SmartBags.name ) then
		return
	end
	
	SmartBags.settings = ZO_SavedVars:New( "SmartBagsSettings" , SmartBags.settingsVersion, nil, SmartBags.settingsDefaults, nil );
	SmartBagsUI:SetAnchor( TOPLEFT, GuiRoot, TOPLEFT, SmartBags.settings.wndMain.x, SmartBags.settings.wndMain.y );
	SmartBagsUI:SetWidth( SmartBags.settings.wndMain.width );
	SmartBagsUI:SetHeight( SmartBags.settings.wndMain.height );
		
	if (SmartBags.settings.ShowInfo ~= 0) then
		ShowInfo = SmartBags.settings.ShowInfo
	end
	
	if (SmartBags.settings.LocalLang == "EN") then
		Lang = SmartBags.settings.LocalLang
	elseif (SmartBags.settings.LocalLang == "FR") then
		Lang = SmartBags.settings.LocalLang
	else
		Lang = "EN"
	end
	
	SmartBags.SetLang()
end

-- ADD_ON_LOADED event
EVENT_MANAGER:RegisterForEvent( "SmartBags" , EVENT_ADD_ON_LOADED , SmartBags.Initialize )

-- Localisation / SlashComand
function SmartBags.SlashCommand(_lang)
	if (_lang == "EN") then
		Lang = "EN"
		SmartBags.settings.LocalLang = Lang
		d(string.format(ShowAddonNameInfo.." > [EN]"))
	elseif (_lang == "FR") then
		Lang = "FR"
		SmartBags.settings.LocalLang = Lang
		d(string.format(ShowAddonNameInfo.." > [FR]"))
	end
	
	SmartBags.SetLang()
end
SLASH_COMMANDS["/smartbags"] = SmartBags.SlashCommand

function SmartBags.SetLang()
	--EN
	if (Lang == "EN") then
		FreeSlots = "Free Slots"
		BagTotalSpace = "Inventory Slots" 
		Money = "Money"
		Bank = "Bank"
		AddonIsMoving = "Addon is moving"
		DisplayOn = "Display enabled on "
	--FR
	elseif (Lang == "FR") then
		FreeSlots = "Emplacements libres"
		BagTotalSpace = "Espace d'inventaire" 
		Money = "Argent"
		Bank = "Banque"
		AddonIsMoving = "Déplacement de l'addon"
		DisplayOn = "Affichage défini sur "
	end
end

function SmartBags.Update()
	bagIcon = ""
	bagSlots = 0	
	bagEmptySlots = 0
	bagIcon, bagSlots = GetBagInfo(1)
	
	for i = 0, bagSlots do
		if CheckInventorySpaceSilently(i) == true then
			bagEmptySlots = i
		end
	end
	
	-- Bags
	ShowInfoBagsText = ""
	ShowInfoMoneyText = ""
	
	if (ShowInfo == 0) then
		-- Text color values in cases			
		if (bagEmptySlots == 0) then
			EmptySlots = "|ccc0000"..bagEmptySlots.."|r"
		elseif ((bagEmptySlots > 0) and (bagEmptySlots <= 20)) then
			EmptySlots = "|ccc6600"..bagEmptySlots.."|r"
		else
			EmptySlots = "|cffffff"..bagEmptySlots.."|r"
		end
		ShowInfoBagsText = (string.format("|cffffcc"..FreeSlots.." : |r"..EmptySlots.."/|cffffff"..bagSlots.."|r"))
	else
		AvailableSpace = "|cffffff"..(bagSlots - bagEmptySlots).."|r"	
		ShowInfoBagsText = (string.format("|cffffcc"..BagTotalSpace.." : |r"..AvailableSpace.."/|cffffff"..bagSlots.."|r"))
	end	
	
	-- Money
	CurrentMoney = "|cffffff"..GetCurrentMoney().."|r"
	
	if (GetBankedMoney() == 0) then
		BankCurrentMoney = "|ccc0000"..GetBankedMoney().."|r"
	else	
		BankCurrentMoney = "|cffffff"..GetBankedMoney().."|r"
	end
	
	ShowInfoMoneyText = (string.format("%s |cffffcc / "..Bank.." : |r%s",CurrentMoney, BankCurrentMoney))
	
	--Display
	SmartBagsUIShowInfos:SetText(ShowInfoBagsText.."  - |cffffcc"..Money.." : |r "..ShowInfoMoneyText)
end

function SmartBags.ChangeInfosSettings(button)
	if (button == 1) then
		SmartBagsUI:SetMovable(true)
		d(string.format(ShowAddonNameInfo.." > "..AddonIsMoving))
	elseif (button == 2) then
		SmartBagsUI:SetMovable(false)
		if (ShowInfo == 0) then
			ShowInfo = 1
			SmartBagsLog = BagTotalSpace
		else
			ShowInfo = 0
			SmartBagsLog = FreeSlots
		end
		
		SmartBags.settings.ShowInfo = ShowInfo
		d(string.format(ShowAddonNameInfo.." > %s(%s)", DisplayOn, SmartBagsLog))
	end	
end

function SmartBags.OnMoveStop(self)
	SmartBags.settings.wndMain.x = self:GetLeft();
	SmartBags.settings.wndMain.y = self:GetTop();
	SmartBags.settings.wndMain.width = self:GetWidth();
	SmartBags.settings.wndMain.height = self:GetHeight();	
end